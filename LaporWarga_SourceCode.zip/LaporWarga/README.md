# 📱 LaporWarga - Smart City App
**Aplikasi Android untuk melaporkan kerusakan fasilitas umum secara real-time**

---

## 🗂️ Struktur Project

```
LaporWarga/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/laporwarga/
│       │   ├── MainActivity.java
│       │   ├── model/
│       │   │   └── Laporan.java              ← Entity Room + Parcelable
│       │   ├── database/
│       │   │   ├── AppDatabase.java          ← Room Database
│       │   │   ├── LaporanDao.java           ← DAO (CRUD)
│       │   │   └── SessionManager.java       ← SharedPreferences
│       │   ├── adapter/
│       │   │   └── LaporanAdapter.java       ← RecyclerView Adapter
│       │   ├── ui/
│       │   │   ├── login/LoginActivity.java  ← Login + Auto-login
│       │   │   ├── home/HomeFragment.java    ← Maps + GPS
│       │   │   ├── lapor/LaporFragment.java  ← Form + Kamera + GPS
│       │   │   ├── riwayat/RiwayatFragment.java ← Daftar Laporan
│       │   │   └── detail/DetailLaporanActivity.java ← Detail (Parcelable)
│       │   ├── service/
│       │   │   └── UploadService.java        ← Background Service + Notifikasi
│       │   └── receiver/
│       │       └── NetworkReceiver.java      ← BroadcastReceiver Koneksi
│       └── res/
│           ├── layout/                       ← Semua file XML layout
│           ├── navigation/nav_graph.xml      ← Navigation Component
│           ├── menu/bottom_nav_menu.xml      ← Bottom Navigation Menu
│           ├── drawable/                     ← Icons & backgrounds
│           ├── xml/file_paths.xml            ← FileProvider paths
│           └── values/                       ← colors, strings, themes
```

---

## ✅ 8 Modul yang Diimplementasikan

| No | Modul | File | Keterangan |
|----|-------|------|-----------|
| 1 | **Navigasi Utama (Fragment)** | `MainActivity.java` | BottomNavigationView + NavController + 3 Fragment |
| 2 | **Penyimpanan Teks (Preferences)** | `SessionManager.java` | SharedPreferences untuk auto-login nama/NIK |
| 3 | **Penyimpanan Tabel (DB)** | `AppDatabase.java`, `LaporanDao.java` | Room Database (SQLite) entitas Laporan |
| 4 | **Peta Cerdas (LBS)** | `HomeFragment.java` | Google Maps SDK + FusedLocationProvider GPS |
| 5 | **Daftar Data (RecyclerView)** | `LaporanAdapter.java`, `RiwayatFragment.java` | RecyclerView + CardView |
| 6 | **Kirim Data / Intent** | `LaporanAdapter.java`, `DetailLaporanActivity.java` | Intent + Parcelable antar Activity |
| 7 | **Akses Perangkat Keras** | `LaporFragment.java` | Runtime permission Kamera + FileProvider |
| 8 | **3 Pilar Belakang Layar** | `UploadService.java`, `NetworkReceiver.java` | Service + BroadcastReceiver + Push Notification |

---

## 🚀 Cara Setup di Android Studio

### 1. Import Project
```
File → Open → pilih folder LaporWarga
```
Tunggu Gradle sync selesai.

### 2. Dapatkan Google Maps API Key
1. Buka https://console.cloud.google.com
2. Buat project baru → aktifkan **Maps SDK for Android**
3. Buat **API Key** → copy key tersebut
4. Buka `AndroidManifest.xml`
5. Ganti `YOUR_GOOGLE_MAPS_API_KEY` dengan API key Anda:
```xml
<meta-data
    android:name="com.google.android.geo.API_KEY"
    android:value="AIzaSy...KEY_ANDA_DI_SINI..." />
```

### 3. Tambahkan Ikon Launcher
Android Studio secara otomatis menggunakan ikon default. Untuk custom:
- Klik kanan `res` → New → Image Asset → pilih gambar

### 4. Run Aplikasi
- Sambungkan HP Android (USB Debugging ON) atau gunakan AVD Emulator
- Klik tombol **Run ▶** atau `Shift+F10`

### 5. Izin yang Diminta Saat Pertama Kali
- Lokasi (untuk GPS & Google Maps)
- Kamera (untuk foto laporan)
- Notifikasi (Android 13+)

---

## 📱 Alur Penggunaan Aplikasi

```
1. BUKA APP
   └─→ LoginActivity: isi nama/NIK → centang "Ingat Saya" → MASUK
       └─→ (Jika sudah pernah login + Ingat Saya) → langsung ke Dashboard

2. BERANDA (HomeFragment)
   └─→ Tampil Google Maps + posisi GPS user saat ini
   └─→ Marker semua laporan ditampilkan di peta

3. LAPOR (LaporFragment)
   └─→ Pilih kategori (Jalan Berlubang, Lampu Mati, dll)
   └─→ Isi nama jalan & keterangan
   └─→ Klik "Ambil Foto" → buka kamera → jepret foto
   └─→ Klik "Ambil Koordinat GPS" → dapat lat/lng otomatis
   └─→ Klik "KIRIM LAPORAN"
       └─→ Data tersimpan ke Room Database
       └─→ UploadService berjalan di background (3 detik)
       └─→ Push Notification "✅ Laporan Diterima!" muncul

4. RIWAYAT (RiwayatFragment)
   └─→ RecyclerView menampilkan semua laporan dari database
   └─→ Klik salah satu → buka DetailLaporanActivity (via Parcelable)
       └─→ Tampil semua data: foto, kategori, lokasi, koordinat, dll

5. NETWORK MONITOR
   └─→ NetworkReceiver aktif selama app terbuka
   └─→ Jika WiFi/Data mati → Toast "⚠️ Jaringan Terputus!"
   └─→ Jika kembali online → Toast "✅ Koneksi Tersambung Kembali!"
```

---

## 🛠️ Tech Stack

- **Language**: Java
- **Min SDK**: 24 (Android 7.0)
- **Target SDK**: 34 (Android 14)
- **Database**: Room (SQLite)
- **Navigation**: Jetpack Navigation Component
- **Maps**: Google Maps SDK + FusedLocationProviderClient
- **Image Loading**: Glide
- **UI**: Material Design Components

---

## ⚠️ Catatan Penting

1. **API Key Maps**: Wajib diisi sebelum run, jika tidak peta tidak akan muncul
2. **GPS Emulator**: Di AVD, set lokasi manual via Extended Controls → Location
3. **Kamera Emulator**: AVD sudah support kamera virtual
4. **Notifikasi Android 13+**: Izin POST_NOTIFICATIONS akan diminta otomatis
