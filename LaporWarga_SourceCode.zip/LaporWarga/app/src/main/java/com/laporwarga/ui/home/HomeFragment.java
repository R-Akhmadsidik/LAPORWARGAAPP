package com.laporwarga.ui.home;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.laporwarga.R;
import com.laporwarga.database.AppDatabase;
import com.laporwarga.database.SessionManager;
import com.laporwarga.databinding.FragmentHomeBinding;
import com.laporwarga.model.Laporan;
import java.util.List;

public class HomeFragment extends Fragment implements OnMapReadyCallback {

    private FragmentHomeBinding binding;
    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private SessionManager sessionManager;
    private static final int LOCATION_PERMISSION_REQUEST = 100;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        sessionManager = new SessionManager(requireContext());
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity());

        binding.tvSambutan.setText("Halo, " + sessionManager.getNama() + "!");

        // Setup Google Maps
        SupportMapFragment mapFragment = (SupportMapFragment)
                getChildFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // Stats laporan
        updateStatistik();
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        // Request lokasi GPS
        if (ActivityCompat.checkSelfPermission(requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
            getCurrentLocation();
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST);
        }

        // Tampilkan marker semua laporan di peta
        tampilkanMarkerLaporan();
    }

    private void getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;

        fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                LatLng currentPos = new LatLng(location.getLatitude(), location.getLongitude());
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentPos, 15f));

                mMap.addMarker(new MarkerOptions()
                        .position(currentPos)
                        .title("Posisi Anda Sekarang"));
            }
        });
    }

    private void tampilkanMarkerLaporan() {
        List<Laporan> laporanList = AppDatabase.getInstance(requireContext())
                .laporanDao().getAllLaporan();

        for (Laporan laporan : laporanList) {
            if (laporan.getLatitude() != 0 && laporan.getLongitude() != 0) {
                LatLng pos = new LatLng(laporan.getLatitude(), laporan.getLongitude());
                mMap.addMarker(new MarkerOptions()
                        .position(pos)
                        .title(laporan.getKategori())
                        .snippet(laporan.getJalan()));
            }
        }
    }

    private void updateStatistik() {
        List<Laporan> laporanList = AppDatabase.getInstance(requireContext())
                .laporanDao().getAllLaporan();
        binding.tvJumlahLaporan.setText(String.valueOf(laporanList.size()));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                onMapReady(mMap);
            } else {
                Toast.makeText(requireContext(), "Izin lokasi diperlukan!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
