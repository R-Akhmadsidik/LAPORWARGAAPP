package com.laporwarga.model;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "laporan")
public class Laporan implements Parcelable {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String namaWarga;
    private String kategori;
    private String jalan;
    private String keterangan;
    private String fotoUri;
    private double latitude;
    private double longitude;
    private String tanggal;
    private String status;

    public Laporan() {}

    protected Laporan(Parcel in) {
        id = in.readInt();
        namaWarga = in.readString();
        kategori = in.readString();
        jalan = in.readString();
        keterangan = in.readString();
        fotoUri = in.readString();
        latitude = in.readDouble();
        longitude = in.readDouble();
        tanggal = in.readString();
        status = in.readString();
    }

    public static final Creator<Laporan> CREATOR = new Creator<Laporan>() {
        @Override
        public Laporan createFromParcel(Parcel in) {
            return new Laporan(in);
        }

        @Override
        public Laporan[] newArray(int size) {
            return new Laporan[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(namaWarga);
        dest.writeString(kategori);
        dest.writeString(jalan);
        dest.writeString(keterangan);
        dest.writeString(fotoUri);
        dest.writeDouble(latitude);
        dest.writeDouble(longitude);
        dest.writeString(tanggal);
        dest.writeString(status);
    }

    @Override
    public int describeContents() { return 0; }

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNamaWarga() { return namaWarga; }
    public void setNamaWarga(String namaWarga) { this.namaWarga = namaWarga; }
    public String getKategori() { return kategori; }
    public void setKategori(String kategori) { this.kategori = kategori; }
    public String getJalan() { return jalan; }
    public void setJalan(String jalan) { this.jalan = jalan; }
    public String getKeterangan() { return keterangan; }
    public void setKeterangan(String keterangan) { this.keterangan = keterangan; }
    public String getFotoUri() { return fotoUri; }
    public void setFotoUri(String fotoUri) { this.fotoUri = fotoUri; }
    public double getLatitude() { return latitude; }
    public void setLatitude(double latitude) { this.latitude = latitude; }
    public double getLongitude() { return longitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }
    public String getTanggal() { return tanggal; }
    public void setTanggal(String tanggal) { this.tanggal = tanggal; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
