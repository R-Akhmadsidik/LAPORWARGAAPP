package com.laporwarga.database;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {

    private static final String PREF_NAME = "LaporWargaSession";
    private static final String KEY_NAMA = "nama_warga";
    private static final String KEY_IS_LOGIN = "is_login";
    private static final String KEY_INGAT_SAYA = "ingat_saya";

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    public SessionManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public void simpanSesi(String nama, boolean ingatSaya) {
        editor.putString(KEY_NAMA, nama);
        editor.putBoolean(KEY_IS_LOGIN, true);
        editor.putBoolean(KEY_INGAT_SAYA, ingatSaya);
        editor.apply();
    }

    public void hapusSesi() {
        editor.clear();
        editor.apply();
    }

    public boolean isLogin() {
        return sharedPreferences.getBoolean(KEY_IS_LOGIN, false);
    }

    public boolean isIngatSaya() {
        return sharedPreferences.getBoolean(KEY_INGAT_SAYA, false);
    }

    public String getNama() {
        return sharedPreferences.getString(KEY_NAMA, "");
    }
}
