package com.laporwarga.ui.detail;

import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.laporwarga.R;
import com.laporwarga.databinding.ActivityDetailLaporanBinding;
import com.laporwarga.model.Laporan;

public class DetailLaporanActivity extends AppCompatActivity {

    private ActivityDetailLaporanBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDetailLaporanBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Terima data Parcelable dari Intent
        Laporan laporan = getIntent().getParcelableExtra("data_laporan");

        if (laporan == null) {
            Toast.makeText(this, "Data tidak ditemukan", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Setup ActionBar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Detail Laporan");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Tampilkan semua data laporan
        binding.tvDetailKategori.setText(laporan.getKategori());
        binding.tvDetailNama.setText(laporan.getNamaWarga());
        binding.tvDetailJalan.setText(laporan.getJalan());
        binding.tvDetailKeterangan.setText(laporan.getKeterangan());
        binding.tvDetailTanggal.setText(laporan.getTanggal());
        binding.tvDetailStatus.setText(laporan.getStatus());
        binding.tvDetailKoordinat.setText(String.format("%.6f, %.6f",
                laporan.getLatitude(), laporan.getLongitude()));

        // Tampilkan foto
        if (laporan.getFotoUri() != null && !laporan.getFotoUri().isEmpty()) {
            Glide.with(this)
                    .load(Uri.parse(laporan.getFotoUri()))
                    .placeholder(R.drawable.ic_photo_placeholder)
                    .into(binding.ivDetailFoto);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
