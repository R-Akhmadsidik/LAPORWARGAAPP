package com.laporwarga.ui.riwayat;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.laporwarga.adapter.LaporanAdapter;
import com.laporwarga.database.AppDatabase;
import com.laporwarga.databinding.FragmentRiwayatBinding;
import com.laporwarga.model.Laporan;
import java.util.List;

public class RiwayatFragment extends Fragment {

    private FragmentRiwayatBinding binding;
    private LaporanAdapter adapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentRiwayatBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        loadData();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData(); // Refresh saat kembali ke fragment
    }

    private void loadData() {
        List<Laporan> laporanList = AppDatabase.getInstance(requireContext())
                .laporanDao().getAllLaporan();

        if (laporanList.isEmpty()) {
            binding.tvKosong.setVisibility(View.VISIBLE);
            binding.recyclerView.setVisibility(View.GONE);
        } else {
            binding.tvKosong.setVisibility(View.GONE);
            binding.recyclerView.setVisibility(View.VISIBLE);
            adapter = new LaporanAdapter(requireContext(), laporanList);
            binding.recyclerView.setAdapter(adapter);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
