package com.laporwarga.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import androidx.core.app.NotificationCompat;
import com.laporwarga.R;

public class UploadService extends Service {

    private static final String CHANNEL_ID = "LaporWargaChannel";
    private static final String CHANNEL_NAME = "LaporWarga Notifikasi";
    private static final int NOTIF_ID_UPLOAD = 1001;
    private static final int NOTIF_ID_SELESAI = 1002;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String namaWarga = intent != null ? intent.getStringExtra("nama_warga") : "Warga";
        String kategori = intent != null ? intent.getStringExtra("kategori") : "Laporan";

        createNotificationChannel();

        // Tampilkan notifikasi "sedang upload"
        Notification uploadNotif = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Mengirim Laporan...")
                .setContentText("Laporan " + kategori + " sedang diproses")
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setProgress(0, 0, true)
                .build();

        startForeground(NOTIF_ID_UPLOAD, uploadNotif);

        // Simulasi proses upload selama 3 detik
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            // Hapus notifikasi upload
            stopForeground(true);

            // Tampilkan notifikasi "Laporan Diterima!"
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            Notification selesaiNotif = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle("✅ Laporan Diterima!")
                    .setContentText("Laporan " + kategori + " dari " + namaWarga + " telah diterima.")
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(true)
                    .build();

            if (manager != null) {
                manager.notify(NOTIF_ID_SELESAI, selesaiNotif);
            }

            stopSelf();
        }, 3000); // 3 detik simulasi upload

        return START_NOT_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Notifikasi status laporan warga");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
