package com.laporwarga.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.Toast;

public class NetworkReceiver extends BroadcastReceiver {

    private boolean wasConnected = true;

    @Override
    public void onReceive(Context context, Intent intent) {
        ConnectivityManager cm = (ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (cm == null) return;

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();

        if (!isConnected && wasConnected) {
            // Koneksi baru saja terputus
            Toast.makeText(context,
                    "⚠️ Jaringan Terputus! Periksa koneksi WiFi/Data Anda.",
                    Toast.LENGTH_LONG).show();
            wasConnected = false;
        } else if (isConnected && !wasConnected) {
            // Koneksi kembali
            Toast.makeText(context,
                    "✅ Koneksi Internet Tersambung Kembali!",
                    Toast.LENGTH_SHORT).show();
            wasConnected = true;
        }
    }
}
