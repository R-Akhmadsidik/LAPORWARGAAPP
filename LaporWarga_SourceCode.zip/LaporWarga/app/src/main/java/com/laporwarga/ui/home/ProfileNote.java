package com.laporwarga.ui.home;

// ProfileFragment bisa ditambahkan sebagai tab ke-4 jika diperlukan
// Untuk UAS ini, cukup 3 tab: Beranda, Lapor, Riwayat
// Fitur logout dapat diakses via menu options di MainActivity

// Jika ingin menambah tab Profil, buat file ProfileFragment.java terpisah
// dan tambahkan ke nav_graph.xml serta bottom_nav_menu.xml
