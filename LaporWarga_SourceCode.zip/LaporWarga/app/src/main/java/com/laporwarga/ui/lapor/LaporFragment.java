package com.laporwarga.ui.lapor;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.laporwarga.database.AppDatabase;
import com.laporwarga.database.SessionManager;
import com.laporwarga.databinding.FragmentLaporBinding;
import com.laporwarga.model.Laporan;
import com.laporwarga.service.UploadService;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LaporFragment extends Fragment {

    private FragmentLaporBinding binding;
    private SessionManager sessionManager;
    private FusedLocationProviderClient fusedLocationClient;
    private Uri fotoUri;
    private double currentLat = 0, currentLng = 0;
    private String currentPhotoPath;

    private static final int LOCATION_PERMISSION_REQ = 200;
    private static final int CAMERA_PERMISSION_REQ = 201;

    private ActivityResultLauncher<Uri> cameraLauncher;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentLaporBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        sessionManager = new SessionManager(requireContext());
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity());

        // Setup spinner kategori
        String[] kategori = {"Jalan Berlubang", "Lampu Jalan Mati", "Tumpukan Sampah",
                "Banjir", "Fasilitas Rusak", "Lainnya"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_spinner_dropdown_item, kategori);
        binding.spinnerKategori.setAdapter(adapter);

        // Setup camera launcher
        cameraLauncher = registerForActivityResult(
                new ActivityResultContracts.TakePicture(),
                result -> {
                    if (result && fotoUri != null) {
                        binding.ivFotoPreview.setImageURI(fotoUri);
                        binding.ivFotoPreview.setVisibility(View.VISIBLE);
                        binding.tvFotoStatus.setText("Foto berhasil diambil ✓");
                    }
                });

        // Tombol ambil foto
        binding.btnAmbilFoto.setOnClickListener(v -> requestCameraAndCapture());

        // Tombol ambil GPS
        binding.btnGetLocation.setOnClickListener(v -> getGPSLocation());

        // Tombol kirim laporan
        binding.btnKirimLaporan.setOnClickListener(v -> kirimLaporan());
    }

    private void requestCameraAndCapture() {
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQ);
        } else {
            openCamera();
        }
    }

    private void openCamera() {
        File photoFile = null;
        try {
            photoFile = createImageFile();
        } catch (IOException e) {
            Toast.makeText(requireContext(), "Gagal membuat file foto", Toast.LENGTH_SHORT).show();
            return;
        }
        if (photoFile != null) {
            fotoUri = FileProvider.getUriForFile(requireContext(),
                    "com.laporwarga.fileprovider", photoFile);
            cameraLauncher.launch(fotoUri);
        }
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "LAPOR_" + timeStamp + "_";
        File storageDir = requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(imageFileName, ".jpg", storageDir);
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }

    private void getGPSLocation() {
        if (ActivityCompat.checkSelfPermission(requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQ);
            return;
        }
        binding.tvKoordinat.setText("Mengambil koordinat...");
        fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                currentLat = location.getLatitude();
                currentLng = location.getLongitude();
                String koordinat = String.format(Locale.getDefault(),
                        "Lat: %.6f, Lng: %.6f", currentLat, currentLng);
                binding.tvKoordinat.setText(koordinat);
                Toast.makeText(requireContext(), "Koordinat berhasil didapat!", Toast.LENGTH_SHORT).show();
            } else {
                binding.tvKoordinat.setText("Gagal mendapat lokasi. Coba lagi.");
            }
        });
    }

    private void kirimLaporan() {
        String jalan = binding.etJalan.getText().toString().trim();
        String keterangan = binding.etKeterangan.getText().toString().trim();
        String kategori = binding.spinnerKategori.getSelectedItem().toString();

        if (jalan.isEmpty() || keterangan.isEmpty()) {
            Toast.makeText(requireContext(), "Isi semua field!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (fotoUri == null) {
            Toast.makeText(requireContext(), "Wajib mengambil foto!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (currentLat == 0 && currentLng == 0) {
            Toast.makeText(requireContext(), "Ambil koordinat GPS terlebih dahulu!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Simpan ke Room Database
        Laporan laporan = new Laporan();
        laporan.setNamaWarga(sessionManager.getNama());
        laporan.setKategori(kategori);
        laporan.setJalan(jalan);
        laporan.setKeterangan(keterangan);
        laporan.setFotoUri(fotoUri.toString());
        laporan.setLatitude(currentLat);
        laporan.setLongitude(currentLng);
        laporan.setTanggal(new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(new Date()));
        laporan.setStatus("Terkirim");

        AppDatabase.getInstance(requireContext()).laporanDao().insert(laporan);

        // Jalankan Background Service untuk simulasi upload
        Intent serviceIntent = new Intent(requireContext(), UploadService.class);
        serviceIntent.putExtra("nama_warga", sessionManager.getNama());
        serviceIntent.putExtra("kategori", kategori);
        requireContext().startService(serviceIntent);

        // Reset form
        resetForm();
        Toast.makeText(requireContext(), "Laporan sedang diproses...", Toast.LENGTH_SHORT).show();
    }

    private void resetForm() {
        binding.etJalan.setText("");
        binding.etKeterangan.setText("");
        binding.tvKoordinat.setText("Koordinat belum diambil");
        binding.ivFotoPreview.setVisibility(View.GONE);
        binding.tvFotoStatus.setText("Belum ada foto");
        fotoUri = null;
        currentLat = 0;
        currentLng = 0;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == CAMERA_PERMISSION_REQ && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            openCamera();
        } else if (requestCode == LOCATION_PERMISSION_REQ && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            getGPSLocation();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
