package com.laporwarga.ui.login;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.laporwarga.MainActivity;
import com.laporwarga.database.SessionManager;
import com.laporwarga.databinding.ActivityLoginBinding;

public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sessionManager = new SessionManager(this);

        // Auto-login jika sesi masih aktif dan "Ingat Saya" dicentang
        if (sessionManager.isLogin() && sessionManager.isIngatSaya()) {
            goToDashboard();
            return;
        }

        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Isi field jika ada sesi sebelumnya
        if (!TextUtils.isEmpty(sessionManager.getNama())) {
            binding.etNama.setText(sessionManager.getNama());
        }

        binding.checkboxIngatSaya.setChecked(sessionManager.isIngatSaya());

        binding.btnMasuk.setOnClickListener(v -> {
            String nama = binding.etNama.getText().toString().trim();
            boolean ingatSaya = binding.checkboxIngatSaya.isChecked();

            if (TextUtils.isEmpty(nama)) {
                binding.etNama.setError("Nama tidak boleh kosong!");
                return;
            }

            sessionManager.simpanSesi(nama, ingatSaya);
            Toast.makeText(this, "Selamat datang, " + nama + "!", Toast.LENGTH_SHORT).show();
            goToDashboard();
        });
    }

    private void goToDashboard() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
