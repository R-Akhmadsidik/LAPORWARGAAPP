package com.laporwarga.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.laporwarga.model.Laporan;
import java.util.List;

@Dao
public interface LaporanDao {

    @Insert
    long insert(Laporan laporan);

    @Update
    void update(Laporan laporan);

    @Delete
    void delete(Laporan laporan);

    @Query("SELECT * FROM laporan ORDER BY id DESC")
    List<Laporan> getAllLaporan();

    @Query("SELECT * FROM laporan WHERE id = :id")
    Laporan getLaporanById(int id);

    @Query("SELECT * FROM laporan WHERE namaWarga = :nama ORDER BY id DESC")
    List<Laporan> getLaporanByNama(String nama);

    @Query("DELETE FROM laporan")
    void deleteAll();
}
