package com.laporwarga.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.laporwarga.R;
import com.laporwarga.model.Laporan;
import com.laporwarga.ui.detail.DetailLaporanActivity;
import java.util.List;

public class LaporanAdapter extends RecyclerView.Adapter<LaporanAdapter.ViewHolder> {

    private Context context;
    private List<Laporan> laporanList;

    public LaporanAdapter(Context context, List<Laporan> laporanList) {
        this.context = context;
        this.laporanList = laporanList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_laporan, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Laporan laporan = laporanList.get(position);

        holder.tvKategori.setText(laporan.getKategori());
        holder.tvJalan.setText(laporan.getJalan());
        holder.tvTanggal.setText(laporan.getTanggal());
        holder.tvStatus.setText(laporan.getStatus());
        holder.tvNama.setText("Oleh: " + laporan.getNamaWarga());

        // Load foto dengan Glide
        if (laporan.getFotoUri() != null && !laporan.getFotoUri().isEmpty()) {
            Glide.with(context)
                    .load(Uri.parse(laporan.getFotoUri()))
                    .placeholder(R.drawable.ic_photo_placeholder)
                    .centerCrop()
                    .into(holder.ivFoto);
        }

        // Set warna status
        int statusColor;
        switch (laporan.getStatus()) {
            case "Diproses": statusColor = context.getColor(R.color.warning); break;
            case "Selesai": statusColor = context.getColor(R.color.success); break;
            default: statusColor = context.getColor(R.color.primary); break;
        }
        holder.tvStatus.setTextColor(statusColor);

        // Klik item -> kirim ke DetailLaporanActivity via Parcelable
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailLaporanActivity.class);
            intent.putExtra("data_laporan", laporan); // Parcelable
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return laporanList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivFoto;
        TextView tvKategori, tvJalan, tvTanggal, tvStatus, tvNama;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivFoto = itemView.findViewById(R.id.iv_foto_laporan);
            tvKategori = itemView.findViewById(R.id.tv_kategori);
            tvJalan = itemView.findViewById(R.id.tv_jalan);
            tvTanggal = itemView.findViewById(R.id.tv_tanggal);
            tvStatus = itemView.findViewById(R.id.tv_status);
            tvNama = itemView.findViewById(R.id.tv_nama_warga);
        }
    }
}
